#!/usr/bin/env python

import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

vel_msg = Twist()
pos_msg = Pose()

def poseCallback(msg):
    pos_msg.x = msg.x
    pos_msg.y = msg.y
    pos_msg.theta = msg.theta

def moveGoal(x1, y1):
    goal_msg = Pose()
    goal_msg.x = x1
    goal_msg.y = y1
    r = rospy.Rate(10)

    while True:

        goal_msg.theta = math.atan2((goal_msg.y - pos_msg.y),(goal_msg.x - pos_msg.x))
        goal_dist = math.sqrt(pow((goal_msg.x - pos_msg.x), 2) + pow((goal_msg.y - pos_msg.y), 2))

        vel_msg.linear.x = 0.5 * (goal_dist)
        vel_msg.angular.z = 4.0 * (goal_msg.theta - pos_msg.theta)
        vel_pub.publish(vel_msg)

        if abs(goal_dist) < 0.01:
            break
        r.sleep()

    vel_msg.linear.x = 0.0
    vel_msg.angular.z = 0.0
    #print("Reached Goal: (" + str(x1) + "," + str(y1) + ")")
    vel_pub.publish(vel_msg)



def orient(degrees):
    angle = math.radians(degrees)
    relative_angle = angle - pos_msg.theta

    if relative_angle < 0:
        clockwise = 1
    else:
        clockwise = 0
    rotate(math.degrees(abs(relative_angle)), 1, clockwise)


def rotate( degrees,angular_speed, isClockwise):
    angle = math.radians(degrees)
    current_angle = 0.0
    t0 = rospy.Time.now().to_sec()
    r = rospy.Rate(100)

    while (current_angle < angle):
        t1 = rospy.Time.now().to_sec()
        current_angle = (angular_speed) * (t1 - t0)
        if isClockwise == True:
            velocity = -abs(angular_speed)
        else:
            velocity = abs(angular_speed)
        #Linear Velocty
        vel_msg.linear.x = 0.0
        vel_msg.linear.y = 0.0
        vel_msg.linear.z = 0.0
        #Angular Velocity
        vel_msg.angular.x = 0.0
        vel_msg.angular.y = 0.0
        vel_msg.angular.z = velocity
        vel_pub.publish(vel_msg)
        r.sleep()

    vel_msg.angular.z = 0.0
    vel_pub.publish(vel_msg)

def move_straight(distance, speed,isForward):
    current_distance = 0.0
    t0 = rospy.Time.now().to_sec()
    r = rospy.Rate(100)

    while (current_distance <= distance):
        t1 = rospy.Time.now().to_sec()
        current_distance = (speed) * (t1 - t0)
        if isForward == True:
            velocity = abs(speed)
        else:
            velocity = -abs(speed)
        #Linear Velocty
        vel_msg.linear.x = velocity
        vel_msg.linear.y = 0.0
        vel_msg.linear.z = 0.0
        #Angular Velocity
        vel_msg.angular.x = 0.0
        vel_msg.angular.y = 0.0
        vel_msg.angular.z = 0.0
        vel_pub.publish(vel_msg)
        r = rospy.Rate(100)

    vel_msg.linear.x = 0.0
    vel_pub.publish(vel_msg)

def start():
    moveGoal(1,1)
    rospy.sleep(0.5)
    orient(0)
    rospy.sleep(0.2)
    move_straight(9, 2, 1)
    rospy.sleep(0.2)
    rotate(90, 2, 0)
    i = 0
    while i < 6:
        i +=1
        move_straight(9, 2, 1)
        rospy.sleep(0.1)
        rotate(90, 1, 0)
        rospy.sleep(0.1)
        move_straight(1, 1, 1)
        rospy.sleep(0.1)
        rotate(90, 2, 0)
        rospy.sleep(0.25)
        move_straight(9, 2, 1)
        rospy.sleep(0.1)
        rotate(90, 2, 1)
        rospy.sleep(0.1)
        move_straight(1, 1, 1)
        rospy.sleep(0.1)
        rotate(90, 2, 1)
    print("Task Completed, Moving to original position")
    moveGoal(5.544445,5.544445)
    rospy.exit()

if __name__ == '__main__':
    rospy.init_node("robot_cleaner")

    pos_sub = rospy.Subscriber("/turtle1/pose", Pose, poseCallback)

    vel_pub = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size = 10)

    vel_msg.linear.x = 0
    vel_msg.angular.z = 0
    vel_pub.publish(vel_msg)

    while not rospy.is_shutdown():
        try:
            #move_straight(input("Distance: "), input("Speed: "), input("isForward: "))
            #rotate(input("Degrees: "), input("Angular_Speed: "), input("isClockwise: "))
            #orient(input("ENTER ORIENTATION DEGREES: "))
            #moveGoal(input("X: "), input("Y: "))
            #ip = bool(input("Start Cleaning: "))
            #if ip == True:
                start()
            #else:
                #print("You Cancelled the cleaning, :\ ")
                #break

        except rospy.ROSInterruptException as e:
            rospy.logerr("ERROR: " + str(es))
